package fenetre;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;


public class dbconnection {
	
	public static void main (String[] args) {
	    
	        String url = "jdbc:mysql://localhost/cantine?useUnicode=true&useJDBCCompliantTimezoneShift=true&useLegacyDatetimeCode=false&serverTimezone=UTC";
	        String user="root";
			String password ="";
			try {
		    	Connection connection = DriverManager.getConnection(url, user, password);
		    	
		    	
		    	if(connection != null) {
		    		System.out.println("Connected");
		    	
		    		
		    		connection.close();
		    	}
		    }catch (SQLException ex) {
		    	ex.printStackTrace();
		    }
	    }
	}

		

