package fenetre;

import org.eclipse.swt.widgets.Display;
import org.eclipse.swt.widgets.Shell;
import org.eclipse.swt.widgets.Button;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.SQLException;

import org.eclipse.swt.SWT;
import org.eclipse.swt.events.SelectionEvent;
import org.eclipse.swt.events.SelectionListener;
import org.eclipse.swt.widgets.Text;
import org.eclipse.swt.widgets.Label;
import org.eclipse.wb.swt.SWTResourceManager;

public class Supprimer {

	protected Shell shlSupprimer;
	private Text textid;

	/**
	 * Launch the application.
	 * @param args
	 */
	public static void main(String[] args) {
		try {
			Supprimer window = new Supprimer();
			window.open();
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	/**
	 * Open the window.
	 */
	public void open() {
		Display display = Display.getDefault();
		createContents();
		shlSupprimer.open();
		shlSupprimer.layout();
		while (!shlSupprimer.isDisposed()) {
			if (!display.readAndDispatch()) {
				display.sleep();
			}
		}
	}

	/**
	 * Create contents of the window.
	 */
	protected void createContents() {
		shlSupprimer = new Shell();
		shlSupprimer.setBackground(SWTResourceManager.getColor(0, 0, 0));
		shlSupprimer.setSize(450, 300);
		shlSupprimer.setText("Supprimer");
		
		Label lblIdDeLutilisateur = new Label(shlSupprimer, SWT.NONE);
		lblIdDeLutilisateur.setForeground(SWTResourceManager.getColor(210, 105, 30));
		lblIdDeLutilisateur.setBackground(SWTResourceManager.getColor(0, 0, 0));
		lblIdDeLutilisateur.setBounds(10, 10, 237, 25);
		lblIdDeLutilisateur.setText("ID de l'utilisateur \u00E0 supprimer");
		
		textid = new Text(shlSupprimer, SWT.BORDER);
		textid.setBackground(SWTResourceManager.getColor(128, 128, 128));
		textid.setForeground(SWTResourceManager.getColor(0, 0, 0));
		textid.setBounds(277, 10, 80, 31);
		
		Button btnSupprimer = new Button(shlSupprimer, SWT.NONE);
		btnSupprimer.setForeground(SWTResourceManager.getColor(210, 105, 30));
		btnSupprimer.setFont(SWTResourceManager.getFont("Segoe Script", 9, SWT.NORMAL));
		btnSupprimer.setBounds(252, 67, 105, 35);
		btnSupprimer.setText("Supprimer");
		btnSupprimer.addSelectionListener(new SelectionListener() {
            public void widgetSelected(SelectionEvent arg0) {
                Del();
            }
            public void widgetDefaultSelected(SelectionEvent arg0) {
            }
          });

	}
	
	void Del() {
		String url = "jdbc:mysql://localhost/cantine?useUnicode=true&useJDBCCompliantTimezoneShift=true&useLegacyDatetimeCode=false&serverTimezone=UTC";
        String user="root";
		String password ="";
		
		try {
	    	Connection connection = DriverManager.getConnection(url, user, password);
	    	String sql = "DELETE FROM user WHERE id=?";
	    	PreparedStatement statement = connection.prepareStatement(sql);
	    	statement.setString(1, textid.getText());
	    	
	    	int rows = statement.executeUpdate();
	    	
	    	if (rows > 0) {
	    		System.out.println("The user's information has been deleted");
	    	}
	    		
	    		connection.close();
	    	
	    }catch (SQLException ex) {
	    	ex.printStackTrace();
	    }
	}

}
