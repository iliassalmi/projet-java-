package fenetre;

import org.eclipse.swt.widgets.Display;
import org.eclipse.swt.widgets.Shell;
import org.eclipse.swt.widgets.Text;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.SQLException;

import org.eclipse.swt.SWT;
import org.eclipse.swt.events.SelectionEvent;
import org.eclipse.swt.events.SelectionListener;
import org.eclipse.swt.widgets.Label;
import org.eclipse.swt.widgets.Button;
import org.eclipse.wb.swt.SWTResourceManager;

public class Ajouter {

	protected Shell shlAjouter;
	private Text textnom;
	private Text textprenom;
	private Text textage;
	private Text textjourcantine;

	/**
	 * Launch the application.
	 * @param args
	 */
	public static void main(String[] args) {
		try {
			Ajouter window = new Ajouter();
			window.open();
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	/**
	 * Open the window.
	 */
	public void open() {
		Display display = Display.getDefault();
		createContents();
		shlAjouter.open();
		shlAjouter.layout();
		while (!shlAjouter.isDisposed()) {
			if (!display.readAndDispatch()) {
				display.sleep();
			}
		}
	}

	/**
	 * Create contents of the window.
	 */
	protected void createContents() {
		shlAjouter = new Shell();
		shlAjouter.setBackground(SWTResourceManager.getColor(0, 0, 0));
		shlAjouter.setSize(353, 271);
		shlAjouter.setText("Ajouter");
		
		Label lblNom = new Label(shlAjouter, SWT.NONE);
		lblNom.setBackground(SWTResourceManager.getColor(0, 0, 0));
		lblNom.setForeground(SWTResourceManager.getColor(205, 133, 63));
		lblNom.setBounds(10, 10, 81, 25);
		lblNom.setText("Nom");
		
		Label lblPrnom = new Label(shlAjouter, SWT.NONE);
		lblPrnom.setForeground(SWTResourceManager.getColor(205, 133, 63));
		lblPrnom.setBackground(SWTResourceManager.getColor(0, 0, 0));
		lblPrnom.setBounds(10, 41, 81, 25);
		lblPrnom.setText("Pr\u00E9nom");
		
		Label lblAge = new Label(shlAjouter, SWT.NONE);
		lblAge.setForeground(SWTResourceManager.getColor(205, 133, 63));
		lblAge.setBackground(SWTResourceManager.getColor(0, 0, 0));
		lblAge.setBounds(10, 72, 81, 25);
		lblAge.setText("Age");
		
		Label lblJourCantine = new Label(shlAjouter, SWT.NONE);
		lblJourCantine.setForeground(SWTResourceManager.getColor(205, 133, 63));
		lblJourCantine.setBackground(SWTResourceManager.getColor(0, 0, 0));
		lblJourCantine.setBounds(10, 103, 97, 25);
		lblJourCantine.setText("Jour Cantine");
		
		textnom = new Text(shlAjouter, SWT.BORDER);
		textnom.setBackground(SWTResourceManager.getColor(128, 128, 128));
		textnom.setBounds(151, 10, 170, 31);
		
		textprenom = new Text(shlAjouter, SWT.BORDER);
		textprenom.setBackground(SWTResourceManager.getColor(128, 128, 128));
		textprenom.setBounds(151, 41, 170, 31);
		
		textage = new Text(shlAjouter, SWT.BORDER);
		textage.setBackground(SWTResourceManager.getColor(128, 128, 128));
		textage.setBounds(151, 72, 170, 31);
		
		textjourcantine = new Text(shlAjouter, SWT.BORDER);
		textjourcantine.setBackground(SWTResourceManager.getColor(128, 128, 128));
		textjourcantine.setBounds(151, 103, 170, 31);
		
		Button btnAjouter = new Button(shlAjouter, SWT.NONE);
		btnAjouter.setFont(SWTResourceManager.getFont("Segoe Script", 11, SWT.NORMAL));
		btnAjouter.setForeground(SWTResourceManager.getColor(205, 133, 63));
		btnAjouter.setBounds(151, 153, 105, 35);
		btnAjouter.setText("Ajouter");
		btnAjouter.addSelectionListener(new SelectionListener() {
            public void widgetSelected(SelectionEvent arg0) {
                Ajt();
            }
            public void widgetDefaultSelected(SelectionEvent arg0) {
            }
          });

	}
	
	void Ajt() {
		String url = "jdbc:mysql://localhost/cantine?useUnicode=true&useJDBCCompliantTimezoneShift=true&useLegacyDatetimeCode=false&serverTimezone=UTC";
        String user="root";
		String password ="";
		
		try {
	    	Connection connection = DriverManager.getConnection(url, user, password);
	    	
	    	String sql = "INSERT INTO user (nom, prenom, age, jourcantine)"
	    			+" VALUES (?, ?, ?, ?)";
	    	
	    	PreparedStatement statement = connection.prepareStatement(sql);
	    	statement.setString(1, textnom.getText());
	    	statement.setString(2, textprenom.getText());
	    	statement.setString(3, textage.getText());
	    	statement.setString(4, textjourcantine.getText());
	    	
	    	int rows = statement.executeUpdate();
	    	
	    	if (rows > 0) {
	    		System.out.println("A new user has been inserted");
	    	}
	    		
	    		connection.close();
	    	
	    }catch (SQLException ex) {
	    	ex.printStackTrace();
	    }
	}
}
