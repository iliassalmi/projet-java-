package fenetre;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.SQLException;

import org.eclipse.swt.widgets.Display;
import org.eclipse.swt.widgets.Shell;
import org.eclipse.swt.widgets.Text;
import org.eclipse.swt.SWT;
import org.eclipse.swt.events.SelectionEvent;
import org.eclipse.swt.events.SelectionListener;
import org.eclipse.swt.widgets.Label;
import org.eclipse.swt.widgets.Button;
import org.eclipse.wb.swt.SWTResourceManager;

public class Modifier {

	protected Shell shlModifier;
	private Text textnom;
	private Text modifnom;
	private Text modifprenom;
	private Text modifage;
	private Text modifjc;

	/**
	 * Launch the application.
	 * @param args
	 */
	public static void main(String[] args) {
		try {
			Modifier window = new Modifier();
			window.open();
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	/**
	 * Open the window.
	 */
	public void open() {
		Display display = Display.getDefault();
		createContents();
		shlModifier.open();
		shlModifier.layout();
		while (!shlModifier.isDisposed()) {
			if (!display.readAndDispatch()) {
				display.sleep();
			}
		}
	}

	/**
	 * Create contents of the window.
	 */
	protected void createContents() {
		shlModifier = new Shell();
		shlModifier.setBackground(SWTResourceManager.getColor(0, 0, 0));
		shlModifier.setSize(450, 300);
		shlModifier.setText("Modifier");
		
		Label lblNomDeLutilisateur = new Label(shlModifier, SWT.NONE);
		lblNomDeLutilisateur.setForeground(SWTResourceManager.getColor(210, 105, 30));
		lblNomDeLutilisateur.setBackground(SWTResourceManager.getColor(0, 0, 0));
		lblNomDeLutilisateur.setBounds(10, 10, 247, 25);
		lblNomDeLutilisateur.setText("Nom de l'utilisateur \u00E0 modifier");
		
		textnom = new Text(shlModifier, SWT.BORDER);
		textnom.setBackground(SWTResourceManager.getColor(128, 128, 128));
		textnom.setBounds(290, 10, 80, 31);
		
		Label lblNom = new Label(shlModifier, SWT.NONE);
		lblNom.setForeground(SWTResourceManager.getColor(210, 105, 30));
		lblNom.setBackground(SWTResourceManager.getColor(0, 0, 0));
		lblNom.setBounds(10, 41, 81, 25);
		lblNom.setText("Nom");
		
		Label lblPrnom = new Label(shlModifier, SWT.NONE);
		lblPrnom.setForeground(SWTResourceManager.getColor(210, 105, 30));
		lblPrnom.setBackground(SWTResourceManager.getColor(0, 0, 0));
		lblPrnom.setBounds(10, 72, 81, 25);
		lblPrnom.setText("Pr\u00E9nom");
		
		Label lblAge = new Label(shlModifier, SWT.NONE);
		lblAge.setForeground(SWTResourceManager.getColor(210, 105, 30));
		lblAge.setBackground(SWTResourceManager.getColor(0, 0, 0));
		lblAge.setBounds(10, 103, 81, 25);
		lblAge.setText("Age");
		
		Label lblJourCantine = new Label(shlModifier, SWT.NONE);
		lblJourCantine.setBackground(SWTResourceManager.getColor(0, 0, 0));
		lblJourCantine.setForeground(SWTResourceManager.getColor(210, 105, 30));
		lblJourCantine.setBounds(10, 134, 105, 25);
		lblJourCantine.setText("Jour Cantine");
		
		modifnom = new Text(shlModifier, SWT.BORDER);
		modifnom.setBackground(SWTResourceManager.getColor(128, 128, 128));
		modifnom.setBounds(140, 41, 80, 31);
		
		modifprenom = new Text(shlModifier, SWT.BORDER);
		modifprenom.setBackground(SWTResourceManager.getColor(128, 128, 128));
		modifprenom.setBounds(140, 72, 80, 31);
		
		modifage = new Text(shlModifier, SWT.BORDER);
		modifage.setBackground(SWTResourceManager.getColor(128, 128, 128));
		modifage.setBounds(140, 103, 80, 31);
		
		modifjc = new Text(shlModifier, SWT.BORDER);
		modifjc.setBackground(SWTResourceManager.getColor(128, 128, 128));
		modifjc.setBounds(140, 134, 80, 31);
		
		Button btnModifier = new Button(shlModifier, SWT.NONE);
		btnModifier.setForeground(SWTResourceManager.getColor(210, 105, 30));
		btnModifier.setBounds(140, 183, 105, 35);
		btnModifier.setText("Modifier");
		btnModifier.addSelectionListener(new SelectionListener() {
            public void widgetSelected(SelectionEvent arg0) {
                Modif();
            }
            public void widgetDefaultSelected(SelectionEvent arg0) {
            }
          });

	}
	
	void Modif() {
		String url = "jdbc:mysql://localhost/cantine?useUnicode=true&useJDBCCompliantTimezoneShift=true&useLegacyDatetimeCode=false&serverTimezone=UTC";
        String user="root";
		String password ="";
		
		try {
	    	Connection connection = DriverManager.getConnection(url, user, password);
	    	String sql = "UPDATE user set nom=?, prenom=?, age=?, jourcantine=? WHERE nom=? ";
	    	PreparedStatement statement = connection.prepareStatement(sql);
	    	statement.setString(1, modifnom.getText());
	    	statement.setString(2, modifprenom.getText());
	    	statement.setString(3, modifage.getText());
	    	statement.setString(4, modifjc.getText());
	    	statement.setString(5, textnom.getText());
	    	
	    	int rows = statement.executeUpdate();
	    	
	    	if (rows > 0) {
	    		System.out.println("The user's information has been updated");
	    	}
	    		
	    		connection.close();
	    	
	    }catch (SQLException ex) {
	    	ex.printStackTrace();
	    }
	}
}

