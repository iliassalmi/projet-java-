package fenetre;

import org.eclipse.swt.widgets.Display;
import org.eclipse.swt.widgets.Shell;
import org.eclipse.swt.widgets.Button;
import org.eclipse.swt.SWT;
import org.eclipse.swt.events.SelectionEvent;
import org.eclipse.swt.events.SelectionListener;
import org.eclipse.wb.swt.SWTResourceManager;
import org.eclipse.swt.widgets.Text;
import org.eclipse.swt.widgets.Label;

public class Accueil {

	protected Shell shlAccueilLogiciel;

	/**
	 * Launch the application.
	 * @param args
	 */
	public static void main(String[] args) {
		try {
			Accueil window = new Accueil();
			window.open();
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	/**
	 * Open the window.
	 */
	public void open() {
		Display display = Display.getDefault();
		createContents();
		shlAccueilLogiciel.open();
		shlAccueilLogiciel.layout();
		while (!shlAccueilLogiciel.isDisposed()) {
			if (!display.readAndDispatch()) {
				display.sleep();
			}
		}
	}

	/**
	 * Create contents of the window.
	 */
	protected void createContents() {
		shlAccueilLogiciel = new Shell();
		shlAccueilLogiciel.setBackground(SWTResourceManager.getColor(SWT.COLOR_BLACK));
		shlAccueilLogiciel.setSize(520, 418);
		shlAccueilLogiciel.setText("Accueil -- Logiciel");
		
		Button btnAjouter = new Button(shlAccueilLogiciel, SWT.NONE);
		btnAjouter.setFont(SWTResourceManager.getFont("Segoe Script", 9, SWT.NORMAL));
		btnAjouter.setSelection(true);
		btnAjouter.setForeground(SWTResourceManager.getColor(205, 133, 63));
		btnAjouter.setBounds(154, 144, 136, 56);
		btnAjouter.setText("Ajouter");
		btnAjouter.addSelectionListener(new SelectionListener() {
            public void widgetSelected(SelectionEvent arg0) {
                Ajouter Ajt = new Ajouter();

                try {
                    Ajouter window = new Ajouter();
                    window.open();
                } catch (Exception e) {
                    e.printStackTrace();
                }

            }
            public void widgetDefaultSelected(SelectionEvent arg0) {
            }
          });
		
		Button btnModifier = new Button(shlAccueilLogiciel, SWT.NONE);
		btnModifier.setForeground(SWTResourceManager.getColor(205, 133, 63));
		btnModifier.setFont(SWTResourceManager.getFont("Segoe Script", 9, SWT.NORMAL));
		btnModifier.setBounds(154, 219, 136, 56);
		btnModifier.setText("Modifier");
		btnAjouter.addSelectionListener(new SelectionListener() {
            public void widgetSelected(SelectionEvent arg0) {
                Modifier Modif = new Modifier();

                try {
                    Modifier window = new Modifier();
                    window.open();
                } catch (Exception e) {
                    e.printStackTrace();
                }

            }
            public void widgetDefaultSelected(SelectionEvent arg0) {
            }
          });
		
		Button btnSupprimer = new Button(shlAccueilLogiciel, SWT.NONE);
		btnSupprimer.setFont(SWTResourceManager.getFont("Segoe Script", 9, SWT.NORMAL));
		btnSupprimer.setForeground(SWTResourceManager.getColor(205, 133, 63));
		btnSupprimer.setBounds(154, 296, 136, 56);
		btnSupprimer.setText("Supprimer");
		
		Label lblAccueil = new Label(shlAccueilLogiciel, SWT.NONE);
		lblAccueil.setFont(SWTResourceManager.getFont("Segoe Script", 13, SWT.NORMAL));
		lblAccueil.setBackground(SWTResourceManager.getColor(0, 0, 0));
		lblAccueil.setForeground(SWTResourceManager.getColor(205, 133, 63));
		lblAccueil.setBounds(154, 24, 250, 92);
		lblAccueil.setText("ACCUEIL");
		btnAjouter.addSelectionListener(new SelectionListener() {
            public void widgetSelected(SelectionEvent arg0) {
                Supprimer supp = new Supprimer();

                try {
                    Supprimer window = new Supprimer();
                    window.open();
                } catch (Exception e) {
                    e.printStackTrace();
                }

            }
            public void widgetDefaultSelected(SelectionEvent arg0) {
            }
          });

	}
}
